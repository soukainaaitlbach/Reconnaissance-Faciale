def send_alert(name):
    print(f"[ALERTE] Visage non autorisé détecté : {name}")
